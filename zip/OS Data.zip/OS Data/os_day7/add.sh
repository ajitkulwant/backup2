#!/bin/bash

function add( )
{
	sum=`expr $1 + $2`
	echo "SUM = $sum"

}

echo "Enter num1"
read num1

echo "Enter num2"
read num2

add $num1 $num2

exit
