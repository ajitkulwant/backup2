#include<stdio.h>
#include<sys/ipc>
#include<sys/shm.h>

#define SHM_KEY 0x6035


typedef struct shm
{
	int cnt;
}shm_t;

int main(void)
{
	shm_t *ptr = NULL;
	int ret,i, status,shmid;
	shmid = shmget(SHM_KEY,sizeof(shm_t),IPC_CREAT|0600);
	if(shmid < 0)
	{
		perror("shmget() faild");
		_exit(1);
	}

	ptr = (shm_t*)shmat(shmid,NULL,0);

	if(ptr == (void*)-1)
	{
		perror("SHMAT faild");
		_exit(2);
	}

	ptr->cnt = 0;
	ret = fork();
	if(ret == )
	{
		for(i=0; i<10; i++)
		{
			
		}
	}
	return 0;
}
