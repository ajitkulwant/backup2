#!/bin/bash


clear

echo "welcome"

echo -n	"today's date is :"
date +"%d/%m/%y"

echo -n "calander"
cal

exit
