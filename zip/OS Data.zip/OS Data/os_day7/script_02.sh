#!/bin/bash

echo -n "num"
read num1
echo -n "num2"
read num2


echo -n "addition:"
sum='expr $num1 + $num2'

echo "sum=$sum"

exit



