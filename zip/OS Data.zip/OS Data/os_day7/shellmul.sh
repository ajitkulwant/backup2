#!/bin/bash



function table( )
{
echo "table of $num is"
for i in {1..10..1}
	do
		sum =`expr $1 \* $i`
		echo " $sum"
		done
}
echo "enter the number"
read num


table $num

	


