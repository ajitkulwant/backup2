#!/bin/bash
clear
i=0
j=0
while [ $i -le 4 ]
	do
		echo "*"
		k=`expr `
		while [ $j -lt $j  ]
			do
				
		done		
		i=`expr $i + 1`
done
