#include<stdio.h>
#include<sys/types.h>
#include<dirent.h>
#include<unistd.h>
int main(int argc,char *argv[])
{
	DIR *dir=NULL;
	struct dirent *ent = NULL;

	if(argc !=2)
	{
		perror("Invalid arguments");
		_exit(1);
	}

   dir=opendir(argv[1]);
	
	if(dir == 0)
	{
		perror("Enter valid directory path");
		_exit(1);
	}
	printf("Dirctory content are %s: ",argv[1]);
	while((ent =readdir(dir))!=NULL) 
	{
//		printf("%-10lu %-20s",ent->d_ino, ent->d_name );
	    printf("%-10lu %-20s\n", ent->d_ino, ent->d_name);
	}
	
	closedir(dir);
	return 0;
}
