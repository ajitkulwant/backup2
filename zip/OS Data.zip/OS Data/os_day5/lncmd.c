#include<stdio.h>
#include<unistd.h>


int main(int argc, char *argv[])
{

	if(argc !=3)
	{

		perror("Ala re error");
		_exit(1);
	}

	if(link(argv[1], argv[2]) == 0)
	{
		printf("Program successfully implemented");
	}

	return 0;
}
