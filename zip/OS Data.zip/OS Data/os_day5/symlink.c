#include<stdio.h>
#include<unistd.h>

int main(int argc, char *argv[])
{
	if(argc !=3)
	{
		perror("Invalid arguments");
		_exit(1);
	}
	if( symlink(argv[1], argv[2]) == 0)
	{
		printf("Zala re run");

	}
	return 0;
}
