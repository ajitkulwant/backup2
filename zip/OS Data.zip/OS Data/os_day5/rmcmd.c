#include<stdio.h>
//#include<unistd.h>

int main(int argc, char *argv[])
{
	if(argc !=2)
	{
		perror("Invalid arguments");
		_exit(1);
	}
  if	(remove(argv[1]) == 0)
	{
		printf("Zala re run");

	}
	return 0;
}
