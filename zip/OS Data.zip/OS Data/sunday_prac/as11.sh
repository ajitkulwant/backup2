#!/bin/bash

clear

echo -n "Enter salary: "
read sal

j=`expr $sal \* 40`
jf=`expr $j / 100`

echo  "hr is  :$jf"

k=`expr $sal \* 20`
kf=`expr $k / 100`

echo  "hrm is : $kf"

m=`expr $jf + $kf`

echo "sum is :$m"
mf=`expr $sal - $m`
echo "GROSS SALARY IS: $mf"


exit
