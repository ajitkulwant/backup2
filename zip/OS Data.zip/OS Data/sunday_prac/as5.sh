#!/bin/bash


echo "Enter number 1 numbers :"
read n1

echo "Enter number 2 numbers :"
read n2


echo "Enter number 3 numbers :"
read n3


if [ $n1 -ge $n2 -a $n1 -ge $n3 ]
	then
		echo "Greatest number is :$n1"
 elif [ $n2 -ge $n3 ]
 		then
		echo "greatest is :$n2"
else
	echo "greatest is :$n3"
 		
fi

