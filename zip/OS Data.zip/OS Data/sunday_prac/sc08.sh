#!/bin/bash

clear

echo -n "number :"
read num
i=1

until [ $i -gt 11 ]
	do
			mul=`expr $i \* $num`
			echo "$mul"
			i=`expr $i + 1`

	done
	exit
