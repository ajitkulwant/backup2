#!/bin/bash


echo "1.DATE"
echo "2.CAl"

echo -n "enter your choice"
read choice

#echo "1.DATE"
#echo "2.CAl"


case $choice in

a)
	echo "todays date is"
	date
	;;
b)
	echo "calender of month"
	cal
	;;
	esac
	exit









