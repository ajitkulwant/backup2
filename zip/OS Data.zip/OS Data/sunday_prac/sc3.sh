#!/bin/bash

clear


echo "enter bredth"
read br

echo "enter width"
read wd

area=`expr $br \* $wd`

echo "area is : $area"


exit

