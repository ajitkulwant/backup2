#include<stdio.h>

   int main(void)
   {
     int i;
     printf("hello");
     scanf("%d",&i);
     printf("Float value is %d \n", i);
     return 0;
  }

