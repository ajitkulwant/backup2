#!/bin/bash

clear

echo "enter number"
read num


for i in 1 2 3 4 5 
	do
		echo "lavdybh"
		i=`expr $1 + 1`
	
	done
j=7

for j in {1..7..1}
	do
		echo "trip"
	   j=`expr $j + 1`


	done
	
