#!/bin/bash

echo "the executable files in currnt directory are :"

for filepath in `ls`
	do	
		if [ -e $filepath -a -x $filepath ]
			then
					echo "$filepath"
			
		fi
	done

	exit
