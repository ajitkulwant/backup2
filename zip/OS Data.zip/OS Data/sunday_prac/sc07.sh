#!/bin/bash

clear

echo "Enter number"
read num
i=1
echo "Table for $num is"

while [ $i -le 10 ]
	do
	mul=`expr $i \* $num`
	echo "$mul"
	i=`expr $i + 1`
	done
exit

