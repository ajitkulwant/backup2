#!/bin/bash

echo "ho chalu zal ahe execution "

pwd | ls *(.x)

echo "bas ka ata zalo ekdach mi run"
