#!/bin/bash

clear


function add()
{
	
	sum=`expr $1 + $3`
	echo "$sum"
}

clear

echo -n "enter num 1:"
read num1

echo -n "enter num 2:"
read num2


add $num1 $num2 15

exit

