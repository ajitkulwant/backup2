#!/bin/bash

clear

pi=3.14

echo -n "Enter radius : "
read rad

area=`echo "2 * $pi * $rad" | bc`

echo  "desired area is : $area"

exit
