#!/bin/bash


echo "enter your path"
read path

if [ -e $path ] 
	then
		if [ -d $path ]
			then
					echo "Is a directory"
		elif [ -f $path ]
			then
					echo "Is a reg file"
		else
				echo "Neither directory noe regular file"
		fi

#echo "pathis valid "

else
	echo "invalid path"
fi

