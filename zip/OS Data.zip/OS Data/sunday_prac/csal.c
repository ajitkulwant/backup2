#include<stdio.h>

int main(void)
{
	int sal,da,hra,gs;

	printf("Enter sal");
	scanf("%d", &sal);

	gs = sal -((sal/100*40) + (sal/100*20));
	printf("GROSS SALARY:%d",gs);
	return 0;
}
