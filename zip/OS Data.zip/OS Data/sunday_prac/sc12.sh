#!/bin/bash

function table()
{
	i=1
	while [ $i -le 10 ]
		do 
			sum=`expr $i \* $num`
			echo "$sum"
			i=`expr $i + 1`
		done


}


echo "Enter number:"
read num
table $num
