#include<stdio.h>
#define LEN 40
int main(void)
{
	int a[LEN]={1,2,3,4,5,6, '\0'};
        
	for(int i=0;i<40;i++)
{
if(a[i]=='\0')
break;
else
printf("%d\n",a[i]);
}
}

