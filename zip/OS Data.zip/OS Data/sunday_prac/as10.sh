   echo "Number"
   read num
   t=1
   res=1
   temp=0
   while [ $t -le $num ]
     do
       
      pp=`expr $temp + $res`
      echo "$pp"
      temp=$res
      res=$pp
			t=`expr $t + 1`
    done
                        
