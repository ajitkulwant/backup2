   #!/bin/bashi
   
   # script to do addition of two pos parameters
   
   echo "no. of positional parameters are: $#" # "#$" enaything which comes after # suppose to be comment 
                                               #but here it will count number of aeguments passed  in terminal
   
   if [ $# -ne 2 ] #here if check pos parameteres are only two
   then
     echo "invalid no. of pos parameters to the script : $0" 
    exit
  fi
  
  sum=`expr $1 + $2` #if only to pos parameter then it will add those parameters
  echo "sum = $sum"
  
  exit
  
                                                                                                                                                                                                                                                                                                                                                                                                                                  
