#!/bin/bash

clear

echo -n "enter the number : "
read num 

if [ `expr $num % 4` -eq 0 -a `expr $num % 100` -ne 0 -o `expr $num % 400` -eq 0 ] 
#if [ `expr $yr % 4` -eq 0 -a `expr $yr % 100` -ne 0 -o `expr $yr % 400` -eq
then
				echo "$num is leap year"
	else 
				echo "$num is not leap year"
fi

exit


