#!/bin/bash

#to show only hidden files in directory

echo "Here pwd is given as input to ls command"
echo ""
pwd | ls -ld .?*

echo ""
echo "Successful implementaion of program "
