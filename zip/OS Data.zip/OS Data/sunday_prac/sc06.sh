#!/bin/bash

clear

echo -n "Enter path :"
read path

if [ -e $path ]
	then
			echo "path is valid"
			
			if [ -f $path ]
				then
						echo "path is valid"
			elif [ -d $path ]
				then 
						echo "path is direcoty"
			else
				echo "neither directory nor regular file"
			fi
	else 
			echo "not valid"

fi	



exit
