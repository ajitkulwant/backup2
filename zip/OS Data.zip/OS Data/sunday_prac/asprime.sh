#!/bin/bash

echo -n "Enter number: "
read num

res =`expr $num / 2`
flag = 0
i = 2

while [ $i -ge $res ]
	do
		
		if [ `expr $num % $i` -eq 0 ]
			then
				flag = 1
					
		fi
	i =`expr $i + 1`
done	

	if [ $flag -eq 1 ]
		then
			echo "Not a Prime"
		else
			echo "prime"
	fi
