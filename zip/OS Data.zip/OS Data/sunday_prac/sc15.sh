#!/bin/bash

pwd

echo -n "Enter filepath:"
read filepath



if [ -f $filepath  ]
	then
		echo "ahe re baba"
	
		else
			echo "Nahi ti"
fi

exit
