#include<stdio.h>
#include"emp.h"
#include<stdlib.h>

void accept_record(emp_t *pe)
{

	printf("Enter empid, name and salary");
//	scanf("%d %s %f",&pe-> empid,pe->name,&pe->sal);
 scanf("%d",&pe->empid);
printf("name\n");
getchar();
gets(pe->name);
 printf("salary\n");
 scanf("%f",&pe->sal);
}

void display_record(emp_t *pe)
{
		printf("%-10d,%-10s,%-20f",pe->empid,pe->name,pe->sal);
}

