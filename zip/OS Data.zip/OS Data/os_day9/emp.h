#ifndef __EMP_H
#define __EMP_H

typedef struct emplyoee
{
	int empid;
	char name[32];
	float sal;
}emp_t;

void accept_record(emp_t *e);
void display_record(emp_t *e);

#endif
