#include<stdio.h>
#include"emp.h"
#include<unistd.h>
int main(void)
{
	int ch,res =1;
	emp_t e;
	
while(1)
{
	printf("");	
	 printf("1.Accept record\n");
   printf("2.Display record\n");
    printf("Enter your choice\n");
    scanf("%d",&ch);

	switch(ch)
	{
		case 0:
		      return 0;
		case 1:
				accept_record(&e);
				break;
		case 2:
				display_record(&e);
				break;
	}
	
//return 0;


}

return 0;
}
