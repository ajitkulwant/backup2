#!/bin/bash
clear
i=0
j=0

for i in 1 2 3 4
	do
			for j in 1 2 3 4
			do
					if [ $j -le $i ]
						then
								echo "* "
					else
								echo -e "\n"
					fi
			#//j=`expr $j + 1 ` 
			#//echo "1:$j"
			done		
			#//i=`expr $i + 1 `
			#//echo "j:$i"
done
