#include<stdio.h>
#include"emp.h"

void accept_record(&e)
{
	printf("Enter empid: ");
	scanf("%d",&e->empid);
	printf("Enter name: ");
	//getchar();
	gets(e->name);
	printf("Salary: ");
	scanf("%f",&salary);
}

void display_record(&e)
{
	printf("%-10d %-10s %-20%f",e->empid,e->name,e->salary);
	

}
