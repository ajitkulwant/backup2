#include<stdio.h>
#include"emp.h"

int main()
{
	int ch;
	printf("0. EXIT\n");
	printf("1. ACCEPT RECORD\n");
	printf("2. DISPLAY RECORD\n");
	printf("\nEnter your choice:");
	emp_t e;
	
	while(1)
	{
		switch(ch)
		{
			case 0:
					return 0;
			case 1:
				printf("YOU HAVE SELECTED TO ENTER RECORD");
				void accept_record(&e);
				printf("RECORD ACCEPETED");
				break;
			case 2:
				printf("WILL DISPLAY RECORD");
				display_record(&e);
				break;
		}

	}
return 0;
}
