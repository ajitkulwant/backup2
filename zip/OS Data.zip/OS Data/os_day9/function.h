#ifndef __FUN_H
#define __FUN_H

void write_record(void);
#endif
