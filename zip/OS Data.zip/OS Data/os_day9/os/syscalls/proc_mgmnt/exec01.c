#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>


int main(void)
{
	int status;
	int ret;
	int err;

	ret = fork();
	if( ret == 0 )//child process
	{
		err = execl("./cmdline.out", "cmdline.out", "one", "two", "three", "four", NULL );
		if( err == -1 )
		{
			perror("exec() failed !!!\n");
			_exit(1);
		}
	}
	else//parent process
	{
		wait(&status);
		printf("parent is exited !!!\n");

	}
	return 0;
}
