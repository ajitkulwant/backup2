/*
	zombie state/defunt state process:
	if child process terminated before its parent and parent is continuing
	its execution without reading an exit status of its child, then child process
	goes into zombie state/defunct state
	in defunct/zombie state: PCB of a child process still exists in a main memory
	even after process termination.

	 - command to check:
	 $ps -e -t pts/0 -o pid,ppid,cmd
	 ---------------------------------------------------------------------------*/

#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main(void)
{
	int ret;
	int i;

	ret = fork();
	if( ret == 0 )//child process
	{
		for( i = 0 ; i <= 20 ; i++ )
		{
			printf("child: i = %d\n", i);
			sleep(1);
		}
		printf("child exited !!!\n");
	}
	else//parent process
	{
		for( i = 0 ; i <= 40 ; i++ )
		{
			printf("parent: i = %d\n", i);
			sleep(1);
		}
		printf("parent exited !!!\n");
	}

	return 0;
}
