#include<stdio.h>
#include<string.h>

int main(void)
{
	char str[132];
	char *cptr = NULL;


	printf("enter the str: ");
	gets(str);

	cptr = strtok(str, " ");
	printf("cptr: %s\n", cptr);

	do
	{
		cptr = strtok(NULL, " ");
		printf("cptr: %s\n", cptr);

	}while(cptr != NULL);


	return 0;
}
