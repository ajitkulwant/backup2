#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>


int main(void)
{
	int ret;
	printf("main() started !!!\n");

	ret = fork();
	if( ret == 0 )
	{
		printf("child: ret = %d\n", ret);
	}
	else
	{
		printf("parent: ret = %d\n", ret);
	}



	printf("main() exited !!!\n");
	return 0;
}
