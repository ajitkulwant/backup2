#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>


int main(void)
{
	int ret;
	printf("main() started !!!\n");

	printf("parent pid = %d\n", getpid());
	printf("parent parent pid = %d\n", getppid());

	ret = fork();
	if( ret == 0 )
	{
		printf("child: ret = %d\n", ret);
		printf("child pid = %d\n", getpid());
		printf("parent pid = %d\n", getppid());
	}
	else
	{
		printf("parent: ret = %d\n", ret);
		printf("parent pid = %d\n", getpid());
		printf("parent parent pid = %d\n", getppid());
	}



	printf("main() exited !!!\n");
	return 0;
}
