#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>


int main(void)
{
	int status;
	int ret;
	int err;

	ret = fork();
	if( ret == 0 )//child process
	{
		char *args[] = {"ls", "-l", "-i", "/home/sunbeam", NULL };

		//err = execl("./cmdline.out", "cmdline.out", "one", "two", "three", "four", NULL );
		//err = execl("/bin/ls", "ls", "-l", "-i", "/home/sunbeam", NULL);
		//err = execlp("ls", "ls", "-l", "-i", "/home/sunbeam", NULL);
		//err = execv("/bin/ls", args);
		err = execvp("ls", args);

		if( err == -1 )
		{
			perror("exec() failed !!!\n");
			_exit(1);
		}
	}
	else//parent process
	{
		wait(&status);
		printf("parent is exited !!!\n");

	}
	return 0;
}
