/*
	to avoid zombie state/defunt state process:
	- to avoid zombie state we can use wait() system call:
	- wait() syscall
		1. pauses an execution of parent process
		2. it reads exit status of the child process from its PCB and pass it to
		the parent process
		3. destroys entry/PCB of the child process 
	 ---------------------------------------------------------------------------*/

#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>

int main(void)
{
	int ret;
	int i;
	int status;

	ret = fork();
	if( ret == 0 )//child process
	{
		for( i = 0 ; i <= 20 ; i++ )
		{
			printf("child: i = %d\n", i);
			sleep(1);
		}
		printf("child exited !!!\n");
		_exit(8);
	}
	else//parent process
	{
		for( i = 0 ; i <= 40 ; i++ )
		{
			printf("parent: i = %d\n", i);
			sleep(1);

			if( i == 20 )
			{
				wait(&status);
				printf("exit value of child proces is: %d\n", WEXITSTATUS(status));
			}
		}
		printf("parent exited !!!\n");
	}

	return 0;
}
