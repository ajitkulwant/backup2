#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<string.h>


int main(void)
{
	int status;
	int ret;
	int err;
	char str[132];
	char *args[32];
	char *cptr = NULL;
	int i;

	while(1)
	{
		//accept command from the user in a string format
		printf("cmd>");
		gets(str);
		i=0;

		//extract all the tokens of the command and store it into arg vector - args
		args[i++] = strtok(str, " ");
		do
		{
			cptr = strtok(NULL, " ");
			args[i++] = cptr;
		}while( cptr != NULL );

		/* it is just for checking
		i=0;
		while(args[i] != NULL )
		{
			printf("args[%d]: %s\n", i, args[i]);
			i++;
		}
		*/

		//args[0] is always a command name
		//if command is an internal command
		if( strcmp(args[0], "exit") == 0 )
			_exit(0);
		else
		if( strcmp(args[0], "cd") == 0 )
			chdir(args[1]);
		else//if command is an external command -> fork() + exec()
		{
			ret = fork();
			if( ret == 0 )//child process
			{
				err = execvp(args[0], args);
				if( err == -1 )
				{
					perror("exec() failed !!!\n");
					_exit(1);
				}
			}
			else//parent process
			{
				wait(&status);
			}
		}
	}//end of while
	return 0;
}
