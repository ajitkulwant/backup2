/*
	 orphan process: if parent process terminated before child, child process
	 becomes orphan, and ownership of an orphan process will be taken by an
	 "init" process.

	 - command to check:
	 $ps -e -t pts/0 -o pid,ppid,cmd
	 ---------------------------------------------------------------------------*/

#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main(void)
{
	int ret;
	int i;

	ret = fork();
	if( ret == 0 )//child process
	{
		for( i = 0 ; i <= 40 ; i++ )
		{
			printf("child: i = %d\n", i);
			sleep(1);
		}
		printf("child exited !!!\n");
	}
	else//parent process
	{
		for( i = 0 ; i <= 20 ; i++ )
		{
			printf("parent: i = %d\n", i);
			sleep(1);
		}
		printf("parent exited !!!\n");
	}

	return 0;
}
