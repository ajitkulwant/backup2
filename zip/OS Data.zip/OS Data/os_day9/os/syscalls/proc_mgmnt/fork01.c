#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>


int main(void)
{
	printf("main() started !!!\n");

	fork();
	fork();
	fork();

	printf("main() exited !!!\n");
	return 0;
}
