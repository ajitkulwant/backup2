#include<stdio.h>
#include<sys/types.h>
#include<dirent.h>
#include<unistd.h>


int main(int argc, char *argv[])
{
	//open dir file
	DIR *dir = NULL; 
	struct dirent *ent = NULL;

	if( argc != 2 )
	{
		perror("invalid no. of args .. pls mention dirpath\n");
		_exit(1);
	}

	dir = opendir(argv[1]);
	if( dir == NULL )
	{
		perror("invalid filepath !!!\n");
		_exit(1);
	}

	printf("contents of the dir %s are: \n", argv[1]);
	//read dir file contents i.e. dir entries
	while( ( ent = readdir(dir) ) != NULL )
	{
		printf("%-10lu %-20s\n", ent->d_ino, ent->d_name);
	}


	//close dir file
	closedir(dir);
	dir = NULL;

	return 0;
}
