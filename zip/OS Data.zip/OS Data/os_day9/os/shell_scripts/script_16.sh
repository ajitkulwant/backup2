#!/bin/bash

# script to give call to other binaries

clear
echo "script_16 started ..."

./pattern.out

echo "script_16 exited ..."
exit



