#!/bin/bash

echo "script_17.sh started ..."

./script_12.sh $*

echo "script_17.sh exited ..."


