#include<stdio.h>
#include"emp.h"
#include"function.h"


#include<unistd.h>
//#include"functions.h"
//#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>



//void write_record(emp_t *pe)
//{
	//printf("IN write function");
//}


void write_record(emp_t *pe)
{
	//open or create a new file
	int fd = open("empdb.db", O_CREAT|O_RDWR|O_APPEND, 0644);
	if( fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}

	//write a record into the file
	write(fd, pe, sizeof(emp_t));

	//close the file
	close(fd);
}

