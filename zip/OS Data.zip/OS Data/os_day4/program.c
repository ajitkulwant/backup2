#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(void)
{
	int pos;

	int fd = open("empdb.db", O_RDONLY);
	if( fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}

	pos = lseek(fd, 0, 0);
	printf("pos = %d\n", pos);

	pos = lseek(fd,20,0);
	printf("pos = %d\n", pos);

	pos = lseek(fd, 30, 1);
	printf("pos = %d\n", pos);
 
	close(fd);

	return 0;
}

