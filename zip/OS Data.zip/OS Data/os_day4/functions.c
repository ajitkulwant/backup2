
#include<unistd.h>
#include"functions.h"
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

void write_record_into_file(emp_t *pe)

{
	int fd = open("empdb.db", O_CREAT|O_RDWR, 0644);
	if(fd == -1)
		{
			perror ("file opening error");
			_exit(1);
		}

		write(fd, pe,sizeof(emp_t));
		close(fd);
}


void read_records_from_file(void)
{
	  emp_t emp;

int fd = open("empdb.db", O_RDONLY);
if( fd == -1)
{ 

     perror("file opening error");
		 _exit(1);
}

printf(" record in the file are:\n");
printf("%-10s %-20s %-10s\n","empid", "name","salary");


while ( read(fd, &emp, sizeof(emp_t) ) > 0)
{
	display_employee_record(&emp);
}

close(fd);
}


int update_record(void)
{
	int id,flag;
	int fd;
	emp_t emp;
	unsigned long int offset= sizeof(emp_t);
	printf("Enter empid to be updated");
	scanf("%d",&id);
	
	fd =open("empdb.db",O_RDWR);
	if(fd == -id)
	{
		perror("File opening error");
		_exit(1);
	}
	
	while(read(fd,&emp,sizeof(emp_t))>0)
	{
		if(id == emp.empid)
		{
			display_employee_record(&emp);
			accept_employee_record(&emp);
			lseek(fd,-offset,SEEK_CUR);
			write(fd,&emp,sizeof(emp_t));
			flag=1;
			break;
		}

	}



}
