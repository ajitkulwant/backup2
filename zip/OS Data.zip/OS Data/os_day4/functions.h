#ifndef __FUN_H
#define __FUN_H

#include"emp.h"

void write_record_into_file(emp_t *pe);
void read_records_from_file(void);
int update_record(void);
void delete_record(void);

#endif
