<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>BookMyCab</title>
		<link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css" />
        <script src="javascripts/functions.js" type="text/javascript"></script>
		<link href="stylesheets/SpryAccordion.css" rel="stylesheet" type="text/css" />
        <script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
		<link href="SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<!--<header id="header">
        <table align="center">
        <tr><td><a href="index.php"><img src="../images/gvpLogo.png" alt="GVPCOE" width="70px" height="70px"></a></td>
        <td><h1 align="center">GVP Academics</h1></td></tr></table>
        <a href="index.php"><img src="../images/banner.jpg" align="middle"></a>
		</header>-->


