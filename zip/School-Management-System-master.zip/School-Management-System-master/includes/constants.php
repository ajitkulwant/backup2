<?php
//database constants
define("server","localhost");
define("user","root");
define("pass","aascar");
define("name","school");

?>