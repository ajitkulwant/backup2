    </body>
</html>

<?php
	// 5. Close connection
	if(isset($connection)){
	mysql_close($connection);
	}
?>