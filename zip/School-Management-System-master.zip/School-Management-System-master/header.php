<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>

<body class="header">
<table width="100%" cellpadding="0" cellspacing="0" align="center">
  <tr>
    <td align="right" width="30%"><img src="images/Logo.png" alt="School Logo" width="70" height="70" align="right" /></td>
    <td align="left" width="50%"><h1 align="left">Nagarjuna Educational Institutions</h1></td>
  </tr>
</table>
</body>
</html>