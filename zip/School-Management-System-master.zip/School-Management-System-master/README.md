# NOT SUPPORTED

#### A pet project done while exploring PHP in college days. This project doesn't implemented any patterns and code organsation (Not mature enough in those days :)). 

##### Fork to develop at your own risk.



# School-Management-System
Using PHP, MYSQL, CSS, JS, HTML
