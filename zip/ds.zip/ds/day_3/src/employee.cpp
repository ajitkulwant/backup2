/*
 * employee.cpp
 *
 *  Created on: 30-Sep-2019
 *      Author: Rohit
 */
#include <iostream>
using namespace std;
#include"employee.h"
