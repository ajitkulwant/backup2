/*
 * node.h
 *
 *  Created on: 29-Sep-2019
 *      Author: Rohit
 */

class list;
class node
{
private:
	employee data;
	node *prev;
	node *next;

public:
	node::node()
	{
		//this->data=NULL;
		this->next=NULL;
		this->prev=NULL;
	}
	void node ::setEmp(employee e)
	{

		this->data=e;

	}

	node();
	void setEmp(employee e);
	friend class list;
	friend class employee;


};


