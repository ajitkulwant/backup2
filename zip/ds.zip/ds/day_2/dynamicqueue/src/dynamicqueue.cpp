

#include <iostream>
using namespace std;
class node
{
private:
	int data;
	node *prev;
	node *next;
public:
	node(int dat)
	{
		this->data=dat;
		this->prev=NULL;
		this->next=NULL;
	}
	friend class list;
};
class list
{
private:
	node *head;
public:
	list()
	{
		this->head=NULL;
	}
	bool empty()
	{
		return (head==NULL);
	}
	void enqueue(int dat)
	{
		node *newnode=new node(dat);
		if(empty())
		{
			head=newnode;
			newnode->next=head;
			newnode->prev=head;
		}
		else
		{
		newnode->prev=head->prev;
		newnode->next=head;
		head->prev->next=newnode;
		head->prev=newnode;

		}
	}
	void dequeue()
	{

	}
	void display()
	{
		node *trav=head;
		//cout<<"..............."<<endl;

		do
		{
			//cout<<"..............."<<endl;
			cout<<trav->data<<endl;
			trav=trav->next;
		}while(trav!=head);
	}
};

int main()
{
	list l1;
	int ch,ele;
		while(1)
		{
			cout<<"0.Exit"<<endl;
			cout<<"1.Enque"<<endl;
			cout<<"2.Deque"<<endl;
			cout<<"3.Display"<<endl;
			cout<<"Enter choice"<<endl;
			cin>>ch;
			switch(ch)
			{
			case 0:
				return 0;
				break;
			case 1:
				cout<<"Enter Element : ";
				cin>>ele;
				l1.enqueue(ele);
				break;
			case 2:
				l1.dequeue();
				break;
			case 3:
				l1.display();
			}
		}
	l1.enqueue(10);

	return 0;
}
