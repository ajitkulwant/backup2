#include <iostream>
#include<vector>
#include<iterator>
using namespace std;
#include<list>
class graph
{
private:
	vector< list < int > > gr;
	int vertex;
	int edges;
public:
	graph()
	{
	this->vertex=0;
	this->edges=0;
	}

void accept()
{
	cout<<"enter the vertex"<<endl;
	cin>>vertex;
	cout<<"enter the edges"<<endl;
	cin>>edges;
	for(int i=0;i<vertex;++i)
	{
	list<int>ajit;
	gr.push_back(ajit);

	}
	for(int i=0;i<edges;++i)
	{
		int from,to;
		cout<<"enter the pair of vertexes  "<<endl;
		cin>>from>>to;
		gr[from].push_back(to);
		gr[to].push_back(from);
	}
}
void display()
{
	list<int>::iterator itr;
	for(int i=0;i<vertex;++i)
	{
		cout << "[ " << i << " ] " << " => ";
		for(itr=gr[i].begin();itr!=gr[i].end();++itr)
			{

				//cout<<"pppppppppppppppppppppppppppppppppppppppppppppppp"<<endl;
				cout<<*itr<<"\t";
			}
		cout<<endl;
	}
}
};
int main()
{
	graph gr;
	gr.accept();
	gr.display();
	return 0;
}
