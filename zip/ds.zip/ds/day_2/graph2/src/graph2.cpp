#include <iostream>
#include<cstring>
using namespace std;
#define SIZE 8
#define INF 9999
class graph
{
private:
	int mat[SIZE][SIZE];
	int vertex;
	int edges;
public:
	graph()
{
		this->vertex=0;
		this->edges=0;
		memset(mat,INF,sizeof(mat));
}
void accept()
{
	cout<<"enter the vertx"<<endl;
	cin>>vertex;
	cout<<"enter the edges"<<endl;
		cin>>edges;

	for(int i=0;i<edges;++i)
	{

		int from,to,weight;
		cout<<"enter the vertices"<<endl;
		cin>>from>>to>>weight;
		mat[from][to]=weight;
		mat[to][from]=weight;
	}

}
void display()
{
	for(int i=0;i<vertex;++i)
	{
		for(int j=0;j<vertex;++j)
		{
			if()
			cout<<mat[i][j]<<"\t";
		}cout<<endl;
	}


}
};
int main()
{
	graph p;
	p.accept();
	p.display();

	return 0;
}
