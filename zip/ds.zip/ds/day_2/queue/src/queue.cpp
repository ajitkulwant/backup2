#include<iostream>
using namespace std;
#define SIZE 5
class Queue
{
	int rear;
	int front;
	int arr[SIZE];
public:
	Queue()
	{
		rear=-1;
		front=-1;
	}
	bool is_full()
	{
		return (rear==SIZE-1);
	}
	bool is_empty()
	{
		return (rear==-1);
	}
	void enque(int a)
	{
		if(!is_full())
		{
			++rear;
			arr[rear]=a;
			if(front==-1)
			{
				++front;
			}
			cout<<arr[rear]<<endl;
		}
		else
		{
			cout<<"Stack is full"<<endl;
		}
	}
	void deque()
	{
		if(!is_empty())
		{
			cout<<"..........................."<<endl;
			cout<<arr[front];
			++front;
		}
		//cout<<"..........................."<<endl;
		//cout<<arr[front];
	}
};
int main()
{
Queue q;
for(int i=1;i<6;i++)
q.enque(10*i);
q.deque();

}
