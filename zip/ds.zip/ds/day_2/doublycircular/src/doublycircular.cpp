#include<iostream>
using namespace std;

class node
{
	node *next;
	node *prev;
	int data;
public:
	node(int d)
	{
		data=d;
		next=NULL;
		prev=NULL;
	}
	friend class dlist;
};
class dlist
{
	node *head;
	int cnt;
public:
	dlist()
	{
		head=NULL;
		cnt=0;
	}
	bool is_empty();
	void add_first(int data);
	void add_last(int data);
	void add_spec(int data,int pos);
	void displayList();
	void deletelast();
	void deletefirst();
	void deletespec(int pos);

};
bool dlist::is_empty()
{
	return(head==NULL);
}
void dlist::deletefirst()
{
head->next->prev=head->prev;
head=head->next;
delete head->prev;
head->prev->next=head;
}

void dlist::add_first(int data)
{
	node *newnode=new node(data);
	cout<<"dlist::add_first(int data)"<<endl;

	newnode->next=head;
	newnode->prev=head->prev;
	head->prev->next=newnode;
	head=newnode;
	newnode->next->prev=newnode;
}
void dlist::add_last(int data)
{
node *newnode=new node(data);
	if(is_empty())
	{
		head=newnode;
		head->next=head;
		head->prev=head;
		++cnt;
	}
	else
	{
		if(head->next==head)
		{
			//node *trav=head;
			head->next=newnode;
			newnode->prev=head;
			newnode->next=head;
		}
		else
		{
			node *trav=head;
			while(trav->next!=head)
			{
				trav=trav->next;
			}
			newnode->prev=trav;
			trav->next=newnode;
			newnode->next=head;
		}
	}
}
void dlist::displayList()
{
	node *trav=head;
	cout<<"head ";
	do
	{
		cout<<" -> "<<trav->data;
		trav=trav->next;
	}while(trav!=head);
}




int main()
{
	dlist d;


	d.add_last(60);
	d.add_last(70);
	d.add_last(80);
	//d.displayList();
	for(int i=5;i>0;i--)
		d.add_first(i*10);
	d.displayList();
	d.deletefirst();
	d.displayList();



/*	d.add_spec(70,5);
	d.displayList();

d.deletelast();
	d.displayList();
	d.deletefirst();
	d.displayList();
	d.deletespec(5);
	d.displayList();*/

return 0;

}
