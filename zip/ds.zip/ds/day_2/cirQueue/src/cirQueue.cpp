#include<iostream>
using namespace std;
#define SIZE 5
class Cqueue
{
	int front;
	int rear;
	int arr[SIZE];
public:
	Cqueue()
	{
		front=-1;
		rear=-1;
	}
	bool is_full()
	{
		return (front==(rear+1)%SIZE);
	}
	bool is_empty()
	{
		return (rear==-1 && front==rear);
	}
	void enqueue(int a)
	{
		if(!is_full())
		{
			rear=(rear+1)%SIZE;
			arr[rear]=a;
			if(front==-1)
			{
				++front;
			}
		}
		else
		{
			cout<<"Queue is full....";
		}
	}
	void deque()
	{
		if(!is_empty())
		{
			front=(front+1)%SIZE;
		}
		else
		{
			cout<<"queue is empty....";
		}
	}
	int getValue()
	{
		return arr[front];
	}
};

int main()
{
	Cqueue cq;
	int ch,ele;
	while(1)
	{
		cout<<"0.Exit"<<endl;
		cout<<"1.Enque"<<endl;
		cout<<"2.Deque"<<endl;
		cout<<"Enter choice"<<endl;
		cin>>ch;
		switch(ch)
		{
		case 0:
			return 0;
			break;
		case 1:
			cout<<"Enter the element"<<endl;
			cin>>ele;
			cq.enqueue(ele);
			break;
		case 2:
			int res=cq.getValue();
			cout<<"Deleted element is: "<<res<<endl;
			cq.deque();
			break;
		}
	}

}
