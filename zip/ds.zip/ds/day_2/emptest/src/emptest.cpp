#include<iostream>
#include<cstring>
using namespace std;

class emp
{
	int eid;
	float sal;
	string name;
public:
	emp()
	{
		eid=0;
		sal=0;
		name=" ";
	}
	friend class node;
	friend ostream &operator<<(ostream &cout,const emp &other);
	friend istream &operator>>(istream &cin,emp &e1);


};
ostream &operator<<(ostream &cout,const emp &other)
{
	cout<<other.eid<<endl;
	cout<<other.sal<<endl;
	cout<<other.name<<endl;
	return cout;
}
istream &operator>>(istream &cin,emp &e1)
{
	cout<<"enter Eid :";
	cin>>e1.eid;
	cout<<endl<<"enter name :";
	cin>>e1.name;
	cout<<endl<<"enter sal :";
	cin>>e1.sal;
	return cin;
}
class node
{
	node *prev;
	node *next;
	emp data;
public:
	node(emp data)
	{
	prev=NULL;
	next=NULL;
	this->data=data;
	}
	friend class list;
};
class list
{
	node *head;
public:
		list()
	{
			head=NULL;
	}
		bool is_empty()
		{
			return (head==NULL);
		}
		void addLast(emp data)
			{
				node *newnode=new node(data);
				if(is_empty())
				{
					head=newnode;
					newnode->next=head;
					newnode->prev=head;
				}
				else
				{
					newnode->next=head;
					newnode->prev=head->prev;
					head->prev->next=newnode;
					head->prev=newnode;
				}
			}
			void display()
			{
				node *trav=head;
				do
				{
					cout<<trav->data;
					trav=trav->next;
				}while(trav!=head);
			}
};

int main()
{
	emp e;
	cin>>e;
	list l1;
	l1.addLast(e);
	cin>>e;

	l1.addLast(e);

	l1.display();
	l1.addLast(e);

	return 0;
}
