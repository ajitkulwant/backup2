
#include <iostream>
#include<vector>
#include<iterator>
#include<algorithm>
using namespace std;

int main()
{
	vector<int> v1;
	v1.push_back(10);
	v1.push_back(20);
	v1.push_back(30);
	v1.push_back(40);
	v1.push_back(50);
	v1.push_back(60);

	for(int i=0;i<v1.size();++i)
		cout<<"\t"<<v1[i]<<endl;

	v1.push_back(5);

	v1.push_back(5);
	v1.pop_back();


	vector<int>::iterator itr;
	for(itr=v1.begin();itr!=v1.end();itr++)
		cout<<"\t"<<*itr<<endl;//smart pointer because object treated as a pointer
	cout<<*min_element(v1.begin(),v1.end());
	return 0;
}
