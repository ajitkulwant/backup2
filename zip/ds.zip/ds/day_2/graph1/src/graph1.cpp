#include <iostream>
#include<cstring>
using namespace std;
#define MAX 8
class graph
{
private:
	int v,e;
	int mat[MAX][MAX];

public:
	graph()
	{
	this->v=0;
	this->e=0;
	 memset(mat,0,sizeof(mat));
	 }
void accept()
{
	cout<<"ENter the no of vertex: ";
	cin>>v;
	cout<<"ENter the no of edges: ";
	cin>>e;
	for(int i=0;i<e;i++)
	{
		int v1,e1;
		cout<<"Enter the pair of vertex"<<endl;
		cin>>v1>>e1;
		mat[v1][e1]=1;
		mat[e1][v1]=1;
	}
}
	void display()
	{
		for(int i=0;i<v;i++)
			{
				for(int j=0;j<v;j++)
				{
					cout<<mat[i][j]<<"\t";
				}
				cout<<endl;
			}
	}


};
int main()
{
	graph g;
	g.accept();
	g.display();
	return 0;
}
