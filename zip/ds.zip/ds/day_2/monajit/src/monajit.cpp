
#include <iostream>
using namespace std;
#define SIZE 7
class stackkul
{
private:
	int top;
	int arr[SIZE];
public:
	stackkul()
	{
		this->top=-1;

	}
bool stack_full()
{

	return(top==SIZE-1);
}
bool stack_empty()
{
	return(top==-1);
}
void push_on_stack(int ele)
{
	if(!stack_full())
	{
		arr[this->top]=ele;
		cout<<"hyb   "<<ele<<endl;
		++top;

	}
	else
		cout<<"stack is full"<<endl;
}
void pop_from_stack()
{
	if(!stack_empty())
	{
		this->top--;
	}
cout<<"popped element"<<arr[this->top]<<endl;
}
int peek_from_stack()
{
	return(this->arr[--this->top]);

}

};
int main()
{
	stackkul st;
	st.push_on_stack(10);
	st.push_on_stack(30);
	st.push_on_stack(40);
	st.push_on_stack(50);
	st.push_on_stack(60);

	st.pop_from_stack();
	st.pop_from_stack();

	int res=st.peek_from_stack();
	cout<<"topmost value"<<res<<endl;

	return 0;
}
