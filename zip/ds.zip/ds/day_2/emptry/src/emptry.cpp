#include <iostream>
#include<string>
using namespace std;
class emp
{
private:
	int empid;
	string name;
	float salary;

public:
	emp(void)
	{
		this->empid=0;
		this->name="";
		this->salary=0.0;
	}

	emp(emp &other)
	{
		this->empid=other.empid;
		this->name=other.name;
		this->salary=other.salary;
	}
	friend ostream &operator<<(ostream &cout,const emp &e1);
	friend istream &operator>>(istream &cin,emp &e1);
	friend class list;

};//end of emp class

istream &operator>>(istream &cin,emp &e1)
{
	cout<<"\nEnter EMP ID ";
	cin>>e1.empid;
	cout<<"\nEnter EMP Name ";
	cin>>e1.name;
	cout<<"\nEnter EMP Salary ";
	cin>>e1.salary;
return cin;

}

ostream &operator<<(ostream &cout,const emp &e1)
{
	cout<<e1.empid<<"	";
	cout<<e1.name<<"	";
	cout<<e1.salary<<"	";
return cout;

}
class node
{
private:
	emp data;
	node *prev=NULL;
	node *next=NULL;

public:
	node(void)
	{
		//this->data=NULL;
		this->next=NULL;
		this->prev=NULL;
	}
	node(emp &data)
	{
		this->data=data;
		this->next=NULL;
		this->prev=NULL;
	}

	friend class list;

}; //end of node class


class list
{
private:
	int cnt;
	node *head= NULL;

public:

	list(void)
	{
		this->cnt=0;
		this->head=NULL;
	}

	bool is_list_empty(void)
	{
		return ( this->head == NULL );
	}

	int get_cnt(void)const
	{
		return ( this->cnt );
	}
	void deleteFirst(void)
			{
				if( !is_list_empty())
				{
					if( head->next == head )
					{

						delete head;
						head = NULL;
						this->cnt=0;
					}
					else
					{
						head->next->prev=head->prev;
						head=head->next;
						delete head->prev->next;
						head->prev->next=head;
					}
				}
				else
					cout << "list is empty !!!" << endl;
			}
	void displayList()
	{
		node *trav=head;
		cout<<endl<<"Emp Details :: "<<endl<<"EMPID EMP_Name EMP_Salary"<<endl;
		if(!is_list_empty())
		{
			do
			{
				cout<<trav->data<<" -> "<<endl;
				trav=trav->next;
			}while(trav!=head);
		}
		else
			cout<<"List is empty"<<endl;
	}
	void deleteLast()
	{
		if(!is_list_empty())
		{
			if(head==head->next)
			{
				delete head;
				head=NULL;
				this->cnt=0;
			}
			else
			{
				head->prev=head->prev->prev;
				delete head->prev->next;
				head->prev->next=head;
				this->cnt--;
			}
		}
		else
		{
			cout<<" List is empty"<<endl;
		}
	}
public:
	void addLast(emp data)
		{
			node *newnode=new node(data);
			if(is_list_empty())
			{
				head=newnode;
				newnode->next=newnode;
				newnode->prev=head;
				this->cnt++;
			}
			else
			{
				newnode->next=head;
				newnode->prev=head->prev;
				head->prev->next=newnode;
				head->prev=newnode;
			}
		}
	void sort(void)
	{
		node *trav=head;
		cout<<endl<<"Emp Details :: "<<endl<<"EMPID EMP_Name EMP_Salary"<<endl;
		int x=0;
		while(x<cnt)
		{

			if(!is_list_empty())
			{
				do
				{
					if(trav->data.salary<trav->next->data.salary)
					{
						float temp=trav->next->data.salary;
						trav->next->data.salary=trav->data.salary;
						trav->data.salary=temp;

						string s_temp=trav->next->data.name;
						trav->next->data.name=trav->data.name;
						trav->data.name=s_temp;

						int i_temp=trav->next->data.empid;
						trav->next->data.empid=trav->data.empid;
						trav->data.empid=i_temp;
					}
					trav=trav->next;
				}while(trav!=head);

			}
			x++;
		}
	}
};//end of list class


int main() {

	list l1;
	emp e1;
	int ch;
	cout<<endl;
	cout<<"0) Exit"<<endl;
	cout<<"1) Insert EMP"<<endl;
	cout<<"2) Delete Last EMP"<<endl;
	cout<<"3) Display all EMP"<<endl;
	cout<<"4) Sort by salary and Display EMP"<<endl;


	while(1)
	{
		cout<<" ENter choice"<<endl;
		cin>>ch;
		switch(ch)
		{
		case 1:
			cin>>e1;
			l1.addLast(e1);
			break;

		case 2:
			l1.deleteLast();
			break;

		case 3:
			l1.displayList();
			break;

		case 4:
			l1.sort();
			break;
		}//end of switch

	}//end of while
	return 0;
}
