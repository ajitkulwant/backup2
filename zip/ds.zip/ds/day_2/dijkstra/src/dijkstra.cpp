#include<iostream>
using namespace std;
#define INF 9999
#define size 9

class Graph5
{
	int v, e, wt;
	int mat[size][size];
public:
	Graph5()
	{
		v=0;
		e=0;
		wt=0;
		for( int i = 0 ; i < size ; i++ )
					for( int j = 0 ; j < size ; j++ )
						mat[i][j] = INF;
	}
	void accept()
	{
		cout<<"enter no of vertices: ";
		cin>>v;
		cout<<endl<<"enter no of edges: ";
		cin>>e;
		for(int i=0;i<e;i++)
		{
			int v1,v2;
			cout<<endl<<"enter no of pair of vertex and weight: ";
			cin>>v1>>v2>>wt;
			mat[v1][v2]=wt;
			mat[v2][v1]=wt;
		}
	}
	void display()
	{
		int k=0;
		cout<<"v......"<<v<<endl;
		cout<<"e..................."<<e<<endl;

		for(int i=0;i<v;i++)
		{
			for(int j=0;j<v;j++)
			{
				if(mat[i][j]!=INF)
					cout<<mat[i][j]<<"\t";
				else
					cout<<'#'<<"\t";
			}		cout<<endl;
		} cout<<endl;

	}
};

int main()
{
	Graph5 g;
	cout<<"------------------------------------"<<endl;
	cout<<"------------------------------------"<<endl;
	g.accept();
	g.display();

	return 0;
}
















