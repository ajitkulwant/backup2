#include <iostream>
using namespace std;
class node
{
private:
	int data;
	node *prev;
	node *next;
public:
	node(int dat)
	{
	this->data=dat;
	this->next=NULL;
	this->prev=NULL;
	}
	friend class list;
};
class list
{
	private:
		node *head;
	public:
		list()
	{
	this->head=NULL;
	}
	bool empty()
	{
		return (head==NULL);

	}
	void add_last(int data)
	{
		node *newnode=new node(data);
		if(empty())
		{
			head=newnode;
			newnode->prev=head;
			newnode->next=head;
		}
		else
		{
			newnode->prev=head->prev;
			newnode->next=head;
			head->prev->next=newnode;
			head->prev=newnode;
			head=newnode;
		}
	}
	void delete_first()
		{
			head=head->next;
			head->prev=head->prev->prev;
			delete head->prev->next;
			head->prev->next=head;

		}
	void add_first(int data)
	{
		node *newnode=new node(data);
			if(empty())
			{
				head=newnode;
				newnode->prev=head;
				newnode->next=head;
			}
			else
			{
		newnode->prev=head->prev;
		newnode->next=head;
		head->prev->next=newnode;
		head->prev=newnode;
		head=newnode;
			}
	}
	void display()
		{
			node *trav=head;
			cout<<"Head ";
			do
			{
				cout<<" -> "<<trav->data;
				trav=trav->next;
			}while(trav->next!=head);
			cout<<"  NULL "<<endl;
		}
	void delete_last()
		{
			head->prev=head->prev->prev;
			delete head->prev->next;
			head->prev->next=head;
		}
	void delete_specific(int loc)
	{
		int i=1;
		node *trav=head;
		while(i!=loc-1)
		{
			trav=trav->next;
			i++;
		}
		trav->next=trav->next->next;
		delete trav->next->prev;
		trav->next->prev=trav;
	}
};
int main()
{
	list l1;
	for(int i=0;i<7;i++)
	l1.add_last(10*i);
	l1.display();
	/*l1.delete_first();
	l1.display();
	l1.add_first(11);
	l1.display();
	l1.delete_last();
	l1.display();*/
	l1.delete_specific(3);
	l1.display();

	return 0;
}
