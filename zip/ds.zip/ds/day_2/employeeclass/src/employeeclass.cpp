
#include <iostream>
#include<list>
#include<cstring>

using namespace std;
class employee
{
private:
	int empid;
	string name;
	float salary;

public:
employee(int empid=0,string name=" ",float salary=0)
	{

		this->empid=empid;
		this->name=name;
		this->salary=salary;

	}
friend ostream &operator<<(ostream &cout,const employee &other)
{
	cout<<"\t"<<other.empid<<endl;
	cout<<"\t"<<other.name<<endl;
	cout<<"\t"<<other.salary<<endl;
	return cout;
}




};
int main()
{
	list<employee>l1;

	l1.push_back( employee(111, "sachin", 1111.11) );
		l1.push_back( employee(222, "nilesh", 2222.22) );
		l1.push_back( employee(333, "sandeep", 3333.33) );
		l1.push_back( employee(444, "rakesh", 4444.44) );
		l1.push_back( employee(555, "amit", 5555.55) );


	list<employee>::iterator itr;
	for( itr=l1.begin();itr!=l1.end();++itr)
		cout<<*itr<<endl;




	return 0;
}
