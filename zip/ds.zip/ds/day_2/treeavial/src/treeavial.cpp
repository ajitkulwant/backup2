#include <iostream>
#include<stack>
#include<queue>
using namespace std;

class node
{
	node *left;
	node *right;
	int data;
public:
	node(int d)
	{
		data=d;
		left=NULL;
		right=NULL;
	}
	friend class tree;
};
class tree
{
	node *root;

public:
	tree()
	{
		root=NULL;
	}

	void accept(int a);
	bool is_empty();
	void preorder();
	void preorder(node *trav);
	void inorder();
	void inorder(node *trav);
	void dfs();
	void bfs();
};

bool tree::is_empty()
{
	return (root==NULL);
}

void tree::dfs()
{
	stack<node *> s;
	s.push(root);
	while(!s.empty())
	{
		node *trav=s.top();
		s.pop();
		cout<<trav->data<<"\t";
		if(trav->right!=NULL)
			s.push(trav->right);
		if(trav->left!=NULL)
			s.push(trav->left);

	}
	cout<<endl;
}

void tree::bfs()
{
	queue<node *> q;
	q.push(root);
	while(!q.empty())
	{
		node *trav=q.front();
		q.pop();
		cout<<trav->data<<"\t";
		if(trav->left!=NULL)
			q.push(trav->left);
		if(trav->right!=NULL)
			q.push(trav->right);
	}
}

void tree::accept(int a)
{
	node *newnode=new node(a);
	if(is_empty())
	{
		root=newnode;
/*
		newnode->left=NULL;
		newnode->right=NULL;
*/
	}
	else
	{
		node *trav=root;
		while(1)
		{
			if( trav->data >= a)
			{
				if(trav->left==NULL)
				{
					trav->left=newnode;
					break;
				}
				else
					trav=trav->left;
			}
			else
			{
				if(trav->right==NULL)
				{
					trav->right=newnode;
					break;
				}
				else
					trav=trav->right;
			}
		}
	}
}

void tree::preorder()
{
	preorder(root);
	cout << endl;
}
void tree::preorder(node *trav)
{
		if(trav==NULL)
			return;
		cout<<trav->data<<"\t";
		preorder(trav->left);
		preorder(trav->right);
}
void tree::inorder()
{
	inorder(root);
	cout << endl;
}
void tree::inorder(node *trav)
{
	if(trav==NULL)
		return;

	inorder(trav->left);
	cout<<trav->data<<"\t";
	inorder(trav->right);
}
int main()
{
	tree t2;
	t2.accept(40);
	t2.accept(20);
	t2.accept(70);
	t2.accept(30);
	t2.accept(10);
	/*t2.preorder();
	t2.inorder();*/
	t2.dfs();
	t2.bfs();
	return 0;
}














