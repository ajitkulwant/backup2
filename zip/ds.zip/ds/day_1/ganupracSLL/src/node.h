#ifndef NODE_H_
#define NODE_H_
#include<cstdlib>
class list;
class node
{
	int data;
	node *next;

public:
	node()
	{
		this->data=0;
		this->next=NULL;
	}
	node(int data)
	{
		this->data=data;
		this->next=NULL;
	}
	friend class list;
};



#endif /* NODE_H_ */
