#include<iostream>
#include "list.h"

int main()
{
	list l1;
	l1.addnode(10);
	l1.addnode(20);
	l1.addnode(30);
	l1.addnode(40);
	l1.displaynode();

	return 0;
}
