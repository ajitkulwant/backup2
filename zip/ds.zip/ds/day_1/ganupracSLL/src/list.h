#ifndef LIST_H_
#define LIST_H_
#include "node.h"

class list
{
	node *head;
public:
	void addnode(int data);
	void displaynode();
	bool empty();
	list(void);
	friend class node;
};



#endif /* LIST_H_ */
