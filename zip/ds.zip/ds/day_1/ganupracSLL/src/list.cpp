#include<iostream>
using namespace std;
#include "list.h"
#include "node.h"

list::list()
{
	this->head=NULL;
}
bool list::empty()
{
	if (head==NULL)
		return true;
	else
		return false;
}

void list::addnode(int data)
{
	node *newnode=new node(data);
	if(empty())
	{
		head=newnode;
	}
	else
	{
		node *trav= head;
		while(trav->next!=NULL)
		{
			trav = trav->next;//move trav pointer to its next node
			cout<<"alo re baba"<<endl;
		}
		trav->next=newnode;

	}
}

void list::displaynode()
{
	node *trav=head;
	if(!empty())
	{
		while(trav!=NULL)
		{
			cout<<trav->data<<"\t"<<endl;
			trav=trav->next;
		}
		cout << "null" << endl;
	}
	else
		cout<<"linked list is empty";
}

