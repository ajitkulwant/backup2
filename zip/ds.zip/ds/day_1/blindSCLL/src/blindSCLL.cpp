#include<iostream>
#include<cstdlib>
using namespace std;


class node
{
	node *next;
	int data;
public:
	node(int data)
	{
		this->data=data;
		this->next=NULL;
	}
	friend class clist;
};

class clist
{
	node *head;
public:
	clist()
	{
		head=NULL;
	}
	bool is_empty();
	void addLast(int data);
	void displayList();
	void addFirst(int data);
	void addSpecific(int data,int pos);
	void deleteLast();


};

bool clist::is_empty()
{
	return (this->head == NULL);
}
void clist::deleteLast()
{
	if(is_empty())
	{
		cout<<"Ab tak koi bhi add nahi hua"<<endl;
	}
	else
	{
		cout<<"void clist::deleteLast()"<<endl;
		node *trav=head;
		while(trav->next->next!=head)
		{
			trav=trav->next;
		}
		delete trav->next;
		trav->next=head;
	}
}
void clist::addSpecific(int data,int pos)
{
	node *newnode=new node(data);
	int i=1;
	node *trav=head;
	while(i!=pos-1)
	{
		trav=trav->next;
		++i;
	}
	newnode->next=trav->next;
	//delete trav->next;
	trav->next=newnode;

}
void clist::addFirst(int data)
{
	node *newnode= new node(data);
	if(is_empty())
	{
		head=newnode;
		newnode->next=head;
	}
	else
	{
		node *trav=head;
		while(trav->next!=head)
			trav=trav->next;
		trav->next=newnode;
		newnode->next=head;
		head =newnode;
	}
}
void clist::addLast(int data)
{
	node *newnode=new node(data);
	if(is_empty())
	{
		head=newnode;
		newnode->next=head;
	}
	else
	{
		node *trav=head;
		while(trav->next!=head)
			trav=trav->next;

		newnode->next=trav->next;
		trav->next=newnode;
	}
}
void clist::displayList()
{
	node *trav=head;
	cout<<"head"<<" -> ";
	do
	{
		cout<<trav->data<<" -> ";
		trav=trav->next;
	}while(trav!=head);
	cout<<" NULL "<<endl;
}
int main()
{
	clist c;
	int ch,data,pos;
	enum choice {EXIT, ADDFIRST, ADDLAST, ADDSPECIFIC, DELETELAST, DISPLAY};
	while(1)
	{
		cout<<"0.EXIT"<<endl;
		cout<<"1.ADD FIRST"<<endl;
		cout<<"2.ADD LAST"<<endl;
		cout<<"3.ADD SPECIFIC"<<endl;
		cout<<"4.DELETE LAST"<<endl;
		cout<<"5.DISPLAY LIST"<<endl;
		cout<<"Enter your choice : ";
		cin>>ch;
		switch(ch)
		{
		case EXIT:
			cout<<"Out of the program...";
			exit(0);
			break;
		case ADDFIRST:
			cout<<"Enter element: ";
			cin>>data;
			c.addFirst(data);
				break;
		case ADDLAST:
			cout<<"Enter element: ";
			cin>>data;
			c.addLast(data);
				break;
		case ADDSPECIFIC:
			cout<<"Enter element: ";
			cin>>data;
			cout<<endl<<"Enter position: ";
			cin>>pos;
			c.addSpecific(data,pos);
				break;
		case DELETELAST:
			c.deleteLast();
				break;
		case DISPLAY:
			c.displayList();
			break;
		}
	}

	return 0;
}
