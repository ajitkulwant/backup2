#include<iostream>
using namespace std;
#define size 5
void sort(int *a)
{
	int i,j=1,key;
	i=j-1;
	while(i>0 && a[i]>key)
	{
		a[i+1]=a[i];
		i=i-1;
	}
	a[i+1]=key;

	for(int i=0;i<size;i++)
	{
		cout<<a[i]<<"   ";
	}
}
int main()
{
	int arr[size]={50,40,10,16,30};
	sort(arr);
}
