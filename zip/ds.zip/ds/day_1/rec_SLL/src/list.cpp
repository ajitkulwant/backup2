

#include<iostream>
using namespace std;
#include<iomanip>
#include"../include/list.h"
#include<cstdlib>


list::list(void)
{
	this->head = NULL;
	this->cnt=0;
}

bool list::is_list_empty(void)
{
	return ( this->head == NULL );
}

int list::get_cnt(void)const
{
	return ( this->cnt );
}

void list::add_node_at_last_position(int data)
{
	node *newnode = new node(data);

	if( is_list_empty() )
	{
		head = newnode;
		this->cnt++;
	}
	else
	{
		node *trav = head;

		while( trav->next != NULL )
			trav = trav->next;
		trav->next =  newnode;
		this->cnt++;
	}
}

void list::add_node_at_first_position(int data)
{
	node *newnode = new node(data);

	if( is_list_empty() )
	{
		head = newnode;
		this->cnt++;
	}
	else
	{
		newnode->next = head;
		head = newnode;
		this->cnt++;
	}
}


void list::add_node_at_specific_position(int data, int pos)
{
	if( pos == 1 )
		add_node_at_first_position(data);
	else
	if( pos == get_cnt() + 1 )
		add_node_at_last_position(data);
	else
	{
		node *newnode = new node(data);
		node *trav = head;
		int i = 1;

		while( i < pos-1 )
		{
			i++;
			trav = trav->next;
		}

		newnode->next = trav->next;
		trav->next = newnode;
		this->cnt++;
	}
}

void list::delete_node_at_first_position(void)
{
	if( !is_list_empty())
	{
		if( head->next == NULL )
		{
			delete head;
			head = NULL;
			this->cnt=0;
		}
		else
		{
			node *temp = head;
			head = head->next;
			delete temp;
			temp = NULL;
			this->cnt--;
		}
	}
	else
		cout << "list is empty !!!" << endl;
}



void list::display_list(void)
{
	if( !is_list_empty())
	{
		node *trav = head;
		cout << "no. of nodes in a list are: " << get_cnt() << endl;
		cout << "list is: head -> ";

		while( trav != NULL )
		{
			cout << trav->data << " -> ";//display data part of the node
			trav = trav->next;//move trav pointer to its next node
		}
		cout << "null" << endl;
	}
	else
		cout << "list is empty !!!" << endl;
}





