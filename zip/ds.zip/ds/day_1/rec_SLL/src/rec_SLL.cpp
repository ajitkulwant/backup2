#include<iostream>
#include <stdlib.h>
using namespace std;
#include"../include/list.h"

int main(void)
{
	list l1;
			l1.add_node_at_last_position(55);
			l1.add_node_at_first_position(55);
			l1.add_node_at_first_position(66);
			l1.add_node_at_first_position(77);
			l1.add_node_at_specific_position(55, 4);
			//l1.delete_node_at_first_position();

}

