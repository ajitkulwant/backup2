
#include<iostream>
using namespace std;
#include"../include/node.h"
#include<cstdlib>

node::node(int data)
{
	this->data = data;
	this->next = NULL;
}



