

#ifndef NODE_H_
#define NODE_H_

class list;

class node
{
private:
	int data;
	node *next;//self referential pointer
public:
	node(int data);
	friend class list;
};



#endif /* NODE_H_ */
