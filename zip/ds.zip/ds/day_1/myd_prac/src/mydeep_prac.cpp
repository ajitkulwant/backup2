#include<iostream>
using namespace std;
class node
{
private:
	int data;
	node *next;

public:
	node(int data)
{
		this->data=data;
		this->next=NULL;

}
	friend class list;
};
class list
{
private:
node *head;
int count ;
public:

	list()
	{
		this->head=NULL;
		this->count=0;

	}
	bool emptylist()
	{
		return(this->head==NULL);
	}
void addlast(int data)
	{
		node *newnode=new node(data);

		if(emptylist())
		{
			head=newnode;
			newnode->next=head;
			this->count++;
		}
		else
		{
			node *trav =head;
			while(trav->next!=head)
			{
				trav=trav->next;

			}
			trav->next=newnode;
			newnode->next=head;
			this->count++;
		}
	}
	void display()
	{
		if(!emptylist())
		{
			node *trav=head;
			do
			{
				cout<<trav->data<<"->";

			trav=trav->next;
			}while(trav!=head);

		}
		cout<<endl;
	}
void addfirst(int data)
{
	node *newnode=new node(data);
	if(emptylist())
	{
		head=newnode;
		newnode->next=head;
		this->count++;

	}
	else
	{
		node*trav=head;
		while(trav->next!=head)
		{
			trav=trav->next;
		}
		trav->next=newnode;
		newnode->next=head;
		head=newnode;
	}


}
void addspecific(int pos,int data)
{
	node *newnode=new node(data);
	node *trav=head;
	int i=1;
	while(i!=pos-1)
	{
		trav=trav->next;
		++i;
	}
	newnode->next=trav->next;
	trav->next=newnode;

}
void deleteatlast()
{
	node * trav=head;
	while(trav->next->next!=head)
	{
		trav=trav->next;
	}
	delete trav->next;
	trav->next=head;
}
void deletefirst()
{
	node*trav=head;
	//node* trav2=head;
	while(trav->next!=head)
	{
		trav=trav->next;
	}
	head=head->next;
	delete trav->next;
	trav->next=head;

}
void deletespecific(int pos)
{
	node *trav=head;
	int i=1;
	while(i!=pos-1)
	{
		trav=trav->next;
		i++;
	}
	node *temp=trav->next->next;
	delete trav->next;
	trav->next=temp;

}
};
int main()
{
	list l1;
	l1.addlast(10);
	l1.addlast(20);
	l1.addlast(30);
	l1.addlast(40);
	l1.addlast(50);
	l1.addlast(60);
	l1.addfirst(5);
	l1.addspecific(3,55);
	l1.display();
	l1.deleteatlast();
	l1.display();
	l1.deletefirst();
	l1.display();
	l1.deletespecific(4);
	l1.display();

}



