#include<iostream>
using namespace std;

class node
{
private:
	int data;
	node *next;
public:
	node(int a)
	{
		this->data=a;
		this->next=NULL;
	}//END OF CTOR
	friend class list;
};//END OF CLASS node

class list
{
	private:
	node *head;
	int cnt;
	public:
	list()
	{
		cnt=0;
		head= NULL;
	}
	void addnode_last(int data);
	void addnode_first(int data);
	void addnode_specific(int data,int pos);
	void deletenode_last();
	void deletenode_first();
	void deletenode_specific(int pos);
	void reverseList(node *temp);
	void reverseList();
	void klogicRev();
	void k2logicRev(node* prev, node* trav);
	void diplayList();
	bool is_empty();
	node *gethead();
};
node* list::gethead(){
	return head;
}
void list::k2logicRev(node* prev, node* trav)
{
	cout<<"..............";
	if(trav==NULL)
	{
		head=prev;
		return;
	}
   k2logicRev(trav, trav->next);
   trav->next=prev;

}

void list::klogicRev()
{
	node *left=NULL;
	node *trav=head;
	node *right=trav->next;
	trav->next=left;

	while(right!=NULL)
	{
		left=trav;
		trav=right;

	    right=trav->next;
		trav->next=left;
	}
	head=trav;;

	}
bool list::is_empty()
{
	return (head==NULL);
}

void list::reverseList()
{
	reverseList(this->head);
}
void list::reverseList(node *temp)
{
	if( temp == NULL )
			return;
	reverseList(temp->next);
	cout<<temp->data<<" -> ";
}
void list::deletenode_specific(int pos)
{
	node *trav=head;
	node *temp;
    int i=1;
	while(i!=pos-1)
	{
		//cout<<endl<<"...........................................List is already empty..I am in delete node"<<endl;
		//cout<<trav->data;

		trav=trav->next;
		++i;
	}
	temp=trav->next->next;
	//cout<<temp->data;
	delete trav->next;
	trav->next=temp;
}
void list::deletenode_first()
{
	node *trav=head;
	if(is_empty())
	{
		cout<<endl<<"List is already empty..I am in delete node"<<endl;
	}
	else
	{
		trav=head->next;
		delete head;
		head=trav;
	}
}

void list::deletenode_last()
{
	node *trav=head;
	if(is_empty())
	{
		cout<<endl<<"List is already empty..I am in delete node"<<endl;
	}
	while(trav->next->next!=NULL)
	{
		trav=trav->next;
	}
	delete trav->next;
	trav->next=NULL;
}

void list::addnode_specific(int data, int pos)
{
	node *newnode=new node(data);
	int i=1;
	if(is_empty())
	{
		head=newnode;
		++cnt;
	}
	else
	{
		node *trav=head;
		while(i!=pos-1)
		{
			trav=trav->next;
			i++;
		}
		newnode->next=trav->next;
		trav->next=newnode;
	}
}

void list::addnode_last(int data)
{
	node *newnode=new node(data);
	if(is_empty())
	{
		head=newnode;
		++cnt;
	}
	else
	{
		node *trav=head;
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=newnode;
		++cnt;
	}
}//END OF ADD_NODE
void list::addnode_first(int data)
{
	node *newnode=new node(data);
	if(is_empty())
	{
		this->head=newnode;
		++cnt;
	}
	else
	{
	node *temp=head;
	head=newnode;
	newnode->next=temp;
	++cnt;
	}
}
void list::diplayList()
{
	static int i=0;
	if(is_empty())
	{
		cout<<"List is empty :"<<endl;
	}
	else
	{
		node *trav=head;
		cout<<endl<<++i<<"  Head -> ";
		while(trav!=NULL)
		{
			cout<<trav->data<<" -> ";
			trav=trav->next;
		}
		cout<<" NULL"<<endl;
	}
}
int main()
{
	list l1;
	for(int j=1;j<7;j++)
	{
		l1.addnode_last(j*10);
	}
	l1.diplayList();
    node *h=l1.gethead();
    cout<<"h "<<h;

	l1.k2logicRev(NULL, h);

	l1.diplayList();
	/*l1.addnode_specific(40,4);
	l1.diplayList();
	l1.deletenode_last();
	l1.diplayList();
	l1.deletenode_first();
	l1.diplayList();
	l1.deletenode_specific(3);
	l1.diplayList();*/
	//l1.reverseList();
	//l1.klogicRev();
    cout<<"==========";

    cout<<"==========";
    l1.diplayList();
	return 0;
}
