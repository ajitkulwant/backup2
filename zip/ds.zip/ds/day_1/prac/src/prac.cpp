
#include <iostream>
#include"array.h"
using namespace std;

//static int count=0;
int main()
{
	int arr[size]={ 1, 2, 3, -1, 2, 1, 0, 4, -1, 7, 8 };

	displayrecord(arr);

	/*if(linear_search(arr))
	cout<<"found";
	else
		cout<<"not found";
	cout<<count;*/
	int res=test(arr);
	cout<<endl<<"result : "<<res;
		return 0;
}

