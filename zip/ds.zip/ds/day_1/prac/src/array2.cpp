#include<iostream>
#include"array.h"
using namespace std;
int count=0;
int ele;

void displayrecord(int *ajit)
{
	for(int i=0;i<size;i++)
		cout<<ajit[i]<<"\t";
}

bool linear_search(int *arr)
{
	int element;
	cout<<"enter the element"<<endl;
	cin>>element;
	for(int i=0;i<size;i++)
	{
		 ++count;
		if(arr[i]==element)
			return true;

	}
	return false;
}
int test(int *arr)
{
	cout<<"..........................";

	int element;
	for(int i=0;i<size;i++)
	{
		for(int j=i+1;j<size;j++)
		{
			 ++count;
			if(arr[i]!=arr[j])
			{
				ele=arr[j];
				return ele;
			}
		}
	}
}


















