#ifndef ARRAY_H_
#define ARRAY_H_
#define size 11
extern int count;
extern int ele;

void displayrecord(int *ajit);
bool linear_search(int *arr);
int test(int *arr);

#endif /* ARRAY_H_ */
