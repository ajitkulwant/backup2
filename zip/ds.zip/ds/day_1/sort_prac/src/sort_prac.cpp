#include <iostream>
using namespace std;
#define size 5
#define swap(a,b) {int t=a; a=b; b=t;}
int comparison;
void bubblesort (int *arr)
{
	for(int i=0;i<size-1;i++)
	{
			for(int pos=0;pos<=size-i-1;++pos)
		{
				comparison++;
			if(arr[pos]>arr[pos+1])
			{
				swap(arr[pos],arr[pos+1]);
			}
		}
	}


}
void selectionsort(int *ak)
{
	for(int first=0;first<size-1;first++)
	{
		for(int cjk=first+1;cjk<size;cjk++)
		{
			if(ak[first]>ak[cjk])
			{
				swap( ak[first] , ak[cjk] );
			}
		}
	}
}
void displayarray(int *arr)
{
	for(int first=0;first<size;first++)
	{
		cout<<arr[first]<<"\t";
	}
	cout<<endl;
}
int main() {
	int arr[size]={90,50,45,95,15};
	//selectionsort(arr);
	//displayarray(arr);
	bubblesort(arr);
	displayarray(arr);
	cout<<endl<<comparison;
	return 0;
}
