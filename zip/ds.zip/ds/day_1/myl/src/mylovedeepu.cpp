#include<iostream>
using namespace std;

class node
{
	node *next;
	node *prev;
	int data;
public:
	node(int d)
	{
		data=d;
		next=NULL;
		prev=NULL;
	}
	friend class dlist;
};
class dlist
{
	node *head;
public:
	dlist()
	{
		head=NULL;
	}
	bool is_empty();
	void add_first(int data);
	void add_last(int data);
	void add_spec(int data,int pos);
	void displayList();
	void deletelast();
	void deletefirst();
	void deletespec(int pos);

};
bool dlist::is_empty()
{
	return(head==NULL);
}


void dlist::add_spec(int data,int pos)
{

	node *newnode=new node(data);
	int i=1;
	node *trav=head;
	while(i!=pos-1)
	{
		++i;
		trav=trav->next;
	}
	newnode->next=trav->next;
	newnode->prev=trav;

	trav->next=newnode;
	newnode->next->prev=newnode;

}

void dlist::add_last(int data)
{
	node *newnode=new node(data);
	if(is_empty())
	{
		head=newnode;
	}
	else
	{
		node *trav=head;
		while(trav->next!=NULL)
		{
		trav=trav->next;
		}
		//newnode->prev=trav->next;
		trav->next=newnode;
		newnode->prev=trav;

	}
}
void dlist::add_first(int data)
{
	//cout<<"void dlist::add_first(int data)"<<endl;
	node *newnode=new node(data);
	if(is_empty())
	{
		head=newnode;
	}
	else
	{
		newnode->next=head;
		head=newnode;
		newnode->next->prev=newnode;
	}
}
void dlist::displayList()
{
	node *trav=head;
	cout<<"Head ";
	while(trav!=NULL)
	{
	cout<<" -> "<<trav->data;
	trav=trav->next;
	}
	cout<<"  NULL"<<endl;
}
void dlist::deletelast()
{
	node *trav=head;
		while(trav->next->next!=NULL)
		{
			trav=trav->next;
		}
	delete trav->next;
	trav->next=NULL;

}
void dlist::deletefirst()
{
	//node *trav=head;
	head=head->next;
	delete head->prev;
	head->prev=NULL;
}
void dlist::deletespec(int pos)
{
	node *trav=head;
	int i=1;
	while(i!=pos-1)
	{
		i++;
		trav=trav->next;
	}
	trav->next=trav->next->next;
	delete trav->next->prev;
	trav->next->prev=trav;
}

int main()
{
	dlist d;
	for(int i=5;i>0;i--)
	d.add_first(i*10);

	d.add_last(60);
	d.add_spec(70,5);
	d.displayList();

/*	d.deletelast();
	d.displayList();
	d.deletefirst();
	d.displayList();*/
	d.deletespec(5);
	d.displayList();

return 0;

}

