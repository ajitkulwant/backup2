#include<iostream>
using namespace std;
#define size 5
bool binary(int *arr)
{
	int mid, key, left=0;
	int right=size-1;
	cout<<"enter no to search"<<endl;
	cin>>key;
	while(left<=right)
	{
		mid=(left+right)/2;

		if(key==arr[mid])
		{
			cout<<"my position is :"<<mid;
			return true;
		}
		else if(key<arr[mid])
		{
			right=mid-1;
		}
		else
			left=mid+1;

	}
	cout<<"I am not there...man...plz enter right number you are not stupid sayankal";
}
bool rec_binary(int *arr,int right,int left,int key)
{
		int mid;
		if(right < left)
			return false;

		mid=(left+right)/2;

		if(key==arr[mid])
		{
			cout<<"my position is :"<<mid;
			return true;
		}
		else if(key<arr[mid])
		{
			rec_binary(arr,mid-1,left,key);
		}
		else
			rec_binary(arr,right,mid+1,key);


	}

/*
void display(arr)
{


}
*/

int main()
{
	int arr[size]={10,20,30,40,50};
	int left=0,key;
	int right=size-1;
	cout<<"Enter the key ;"<<endl;
	cin>>key;
	rec_binary(arr,right,left,key);
}
