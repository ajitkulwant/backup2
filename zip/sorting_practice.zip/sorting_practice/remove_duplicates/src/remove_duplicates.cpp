//============================================================================
// Name        : remove_duplicates.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>

using namespace std;
int fun(char *);
int main() {
	char *str="raajaa";
	cout<<"hello";

	int len=fun(str);
	cout<<len;
	for(int i=0;i<len;i++)
	{
       cout<<str[i];
	}
	return 0;
}

int fun(char *p)
{
    int i=1,j=0;
    int n=6;
    cout<<"inside fun";
    for( i=1;i<n;i++)
    {
    	cout<<"inside for 1";
    	for(j=i-1;j>=0;j--)
    	{
        	cout<<"inside for 2";

    		if(p[j]==p[i])
    		{
    			j=i;
    			n=n-1;
    			while(j< n)
    			{
    				p[j]=p[j+1];
    				j=j+1;
    			}
    			break;
    		}
    	}

    }
    return n;

}

