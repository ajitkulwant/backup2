//============================================================================
// Name        : Bubble_sort.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void swap1(int *, int *);

int main() {
   int i=0,j=0,flag=0;
	 int arr[]={5,4,3,2,1};

	 for(i=0;i<4;i++)
	 	 {
	 	flag=0;
	 		 for(j=0;j<(4-i);j++)
	 		 {
	 			 if(arr[j+1]<arr[j])
	 			 {
	 				 swap1(&arr[j+1], &arr[j]);
	 				 flag=1;}
	 		 }
	 		 if(flag==0)
	 			 break;
	 	 }


	 	 for(i=0;i<5;i++)
	 	 {
	 		 cout<<arr[i];
	 	 }


	return 0;
}

void swap1(int *p, int *q)
{
	int temp;
	temp=*p;
	*p=*q;
	*q=temp;
}
