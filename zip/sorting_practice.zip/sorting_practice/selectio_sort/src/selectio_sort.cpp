//============================================================================
// Name        : selectio_sort.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void swap1(int *, int *);

int main() {

	 int i=0, j=0, k=0;
	 int arr[]={5,4,3,2,1};
	 for(i=0;i<4;i++)
	 {
		 k=i;
		 for(j=i+1;j<5;j++)
		 {
			 if(arr[k]>arr[j])
				 k=j;
		 }
		 swap1(&arr[i], &arr[k]);
	 }
	 for(i=0;i<5;i++)
	 {
		 cout<<arr[i];
	 }
	return 0;
}

void swap1(int *p, int *q)
{
	int temp;
	temp=*p;
	*p=*q;
	*q=temp;
}

