//============================================================================
// Name        : pattern.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;


int main() {

	int row=4;
	char a='A';

	for(int i=1;i<=row;++i){

		for(int s=1;s<=row-i;++s)
			cout<<" ";

		for(int str=1;str<=i;++str)
		{
			if(i<=2)
			{
				cout<<"* ";
			}
			else if(str==1)
			{
				cout<<"* ";
			}
			else if(str==i)
			{
				cout<<"* ";
			}
			else
			{
				cout<<"  ";
			}
		}

		cout<<endl;

	}

	for(int i=row-1;i>=0;--i){

			for(int s=1;s<=row-i;++s)
				cout<<" ";

			for(int str=1;str<=i;++str)
			{
				if(i<=2)
				{
					cout<<"* ";
				}
				else if(str==1)
				{
					cout<<"* ";
				}
				else if(str==i)
				{
					cout<<"* ";
				}
				else
				{
					cout<<"  ";
				}
			}

			cout<<endl;

		}

	return 0;
}

















int main2() {

	int row=4;
	char a='A';

	for(int i=1;i<=row;++i){

		for(int s=1;s<=row-i;++s)
			cout<<" ";

		for(int str=1;str<=i;++str)
					cout<<"* ";

		cout<<endl;

	}


	for(int i=row-1;i>=1;--i){

		for(int s=1;s<=row-i;++s)
			cout<<" ";

		for(int str=1;str<=i;++str)
					cout<<"* ";

		cout<<endl;

	}


	return 0;
}
