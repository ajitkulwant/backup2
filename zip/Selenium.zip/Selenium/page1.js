// get the webdriver
const webdriver = require('selenium-webdriver')

function testCase1() {
    // load the browser
    const driver = new webdriver.Builder().forBrowser('chrome').build()

    // open the brower and browse google.com
    driver.get('https://google.com')

    // quit the browser
    //driver.quit()
}

testCase1()
