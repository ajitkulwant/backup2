/* filename: functions.c
	 this file contains definitions of fileio operations
	 -----------------------------------------------------------*/

#include<unistd.h>
#include"functions.h"
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

void delete_record(void)
{
	int id;
	emp_t emp;
	int fs, fd;

	//accept empid from the user
	printf("enter an empid: ");
	scanf("%d", &id);

	//open original file in readonly mode and create a temp file
	fs = open("empdb.db", O_RDONLY);
	fd = open("temp.db", O_CREAT|O_WRONLY, 0644);
	if( fs == -1 || fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}

	//read all the records from an original file one by one
	while( read(fs, &emp, sizeof(emp_t)) > 0 )
	{
		//copy all the records from original file to the temp file except record which
		//to be deleted
		if( id != emp.empid )
		{
			write(fd, &emp, sizeof(emp_t));
		}
	}

	//close both the files
	close(fs);
	close(fd);

	//delete an original file
	unlink("empdb.db");

	//rename temp file by original filename
	rename("temp.db", "empdb.db");

}

int update_record(void)
{
	int id;
	int fd;
	emp_t emp;
	int flag = 0;
	unsigned long int offset = sizeof(emp_t);

	//accept an empid of an employee which is to be update
	printf("enter empid of an employee: ");
	scanf("%d", &id);

	//open a file for read as well write purpose
	fd = open("empdb.db", O_RDWR);
	if( fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}

	//search a record
	while( read(fd, &emp, sizeof(emp_t)) > 0 )
	{
		//if found update it
		if( emp.empid == id )
		{
			display_employee_record(&emp);
			accept_employee_record(&emp);
			lseek(fd, -offset, SEEK_CUR);
			write(fd, &emp, sizeof(emp_t));
			flag = 1;
			break;
		}
	}

	//close a file
	close(fd);

	//return result either true or false accordingly
	return flag;
}

void read_records_from_file(void)
{
	emp_t emp;
	//open a file for read only
	int fd = open("empdb.db", O_RDONLY);
	if( fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}

	printf("records in the file are: \n");
	printf("%-10s %-20s %-10s\n", "empid", "name", "salary");

	//read all the records from the file
	while ( read(fd, &emp, sizeof(emp_t) ) > 0 )
	{
		display_employee_record(&emp);
	}


	//close a file
	close(fd);
}

void write_record_into_file(emp_t *pe)
{
	//open or create a new file
	int fd = open("empdb.db", O_CREAT|O_RDWR|O_APPEND, 0644);
	if( fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}

	//write a record into the file
	write(fd, pe, sizeof(emp_t));

	//close the file
	close(fd);
}
