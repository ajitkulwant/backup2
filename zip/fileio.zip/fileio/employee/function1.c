#include<unistd.h>
#include"functions.h"
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

void delete_record(void)
{
	int id;
	emp_t emp;
	int fs, fd;

	//accept empid from the user
	printf("enter an empid: ");
	scanf("%d", &id);

	//open original file in readonly mode and create a temp file
	fs = open("empdb.db", O_RDONLY);
	fd = open("temp.db", O_CREAT|O_WRONLY, 0644);
	if( fs == -1 || fd == -1 )
	{
		perror("file opening error !!!\n");
		_exit(1);
	}
}
